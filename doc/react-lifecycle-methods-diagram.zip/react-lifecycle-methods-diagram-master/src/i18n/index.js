/* eslint-disable import/extensions */

import t from './t.js';
import T from './T.jsx';

export { t };

export default T;
