import Mounting from './Mounting';
import Updating from './Updating';
import Unmounting from './Unmounting';

/* eslint-disable sort-keys */
export default {
  Mounting,
  Updating,
  Unmounting,
};
