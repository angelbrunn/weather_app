import React from 'react';

import './Footer.less';

import GitHub from './GitHub';

export default () => (
  <footer>
    <GitHub />
  </footer>
);
